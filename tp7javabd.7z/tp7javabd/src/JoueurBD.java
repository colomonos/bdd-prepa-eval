import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JoueurBD {
	ConnexionMySQL laConnexion;
	Statement st;
	
	JoueurBD(ConnexionMySQL laConnexion){
		this.laConnexion=laConnexion;
	}

	int maxNumJoueur() throws SQLException{
		this.st = this.laConnexion.createStatement();
		ResultSet a = this.st.executeQuery("select max(numJoueur) maxnJoueur from JOUEUR");
		a.next();
		return a.getInt("maxnJoueur");

		

	}


	int insererJoueur( Joueur j) throws  SQLException{
		return -1;
	}


	void effacerJoueur(int num) throws SQLException {
	}

    	void majJoueur(Joueur j)throws SQLException{
    	}

    	Joueur rechercherJoueurParNum(int num)throws SQLException{
    		return null;
    	}

	ArrayList<Joueur> listeDesJoueurs() throws SQLException{
		return null;
	}
	
	String rapportMessage() throws SQLException{
		return "A faire";
	}
	
	String rapportMessageComplet() throws SQLException{
		return "A faire";	
   	}
}
